window.__tidalOriginExtension = true;
